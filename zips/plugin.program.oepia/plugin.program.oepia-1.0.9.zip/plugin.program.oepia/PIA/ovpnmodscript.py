import os

startdir = 'C:\Users\Dad\Desktop\openvpn\PIA'
filelist=os.listdir(startdir)
for stuff in filelist:
    if not 'Done' or not 'network' in stuff:    
        print stuff
        link = open(startdir+'/'+stuff, "r")
        file = link.read()
        #file=file.replace('ca /storage/.config/vpn-config/ca.crt','ca /storage/.config/vpn-config/ca.crt')
        file=file.replace('crl-verify /storage/.config/vpn-config/crl.pem','crl-verify /storage/.config/vpn-config/crl.pem')
        link = open(startdir+'/'+stuff, "w")
        link.write(file)



